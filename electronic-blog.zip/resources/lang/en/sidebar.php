<?php

return [
    'dashboard'       => 'Dashboard',
    'sections'        => 'Sections',
    'sub_sections'    => 'Sub Sections',
    'posts'           => 'Posts',
    'about_us'        => 'About Us',
    'contact_us'      => 'Contact Us',
    'users'           => 'Users',
    'all_users'       => 'Users',
    'writers'         => 'Writers',
];
