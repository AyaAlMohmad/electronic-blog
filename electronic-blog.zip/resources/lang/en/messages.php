<?php
return [
    'Approve Writer' => 'Approve Writer',
    'Current User Info' => 'Current User Info',
    'Name' => 'Name',
    'Email' => 'Email',
    'Biography' => 'Biography',
    'Subsection' => 'Subsection',
    'Select Subsection' => 'Select Subsection',
    'Profile Image' => 'Profile Image',
    'Leave empty to use current profile image' => 'Leave empty to use current profile image',
    'Back' => 'Back',
];
