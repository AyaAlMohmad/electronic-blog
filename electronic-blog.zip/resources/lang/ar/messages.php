<?php
return [
    'Approve Writer' => 'الموافقة على الكاتب',
    'Current User Info' => 'معلومات المستخدم الحالية',
    'Name' => 'الاسم',
    'Email' => 'البريد الإلكتروني',
    'Biography' => 'السيرة الذاتية',
    'Subsection' => 'القسم الفرعي',
    'Select Subsection' => 'اختر القسم الفرعي',
    'Profile Image' => 'الصورة الشخصية',
    'Leave empty to use current profile image' => 'اتركه فارغًا لاستخدام الصورة الحالية',
    'Back' => 'رجوع',
];
