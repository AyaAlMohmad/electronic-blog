<?php

return [
    'dashboard'       => 'لوحة التحكم',
    'sections'        => 'الأقسام',
    'sub_sections'    => 'الأقسام الفرعية',
    'posts'           => 'المشاركات',
    'about_us'        => 'من نحن',
    'contact_us'      => 'اتصل بنا',
    'users'           => 'المستخدمون',
    'all_users'       => 'كل المستخدمين',
    'writers'         => 'الكتاب',
];
