
<?php $__env->startSection('content'); ?>

<!-- Section table -->
<section id="configuration">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo app('translator')->get('admin.sections.title'); ?></h4>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse" title="<?php echo app('translator')->get('admin.sections.card.collapse'); ?>"><i class="ft-minus"></i></a></li>
                            <li><a data-action="reload" title="<?php echo app('translator')->get('admin.sections.card.reload'); ?>"><i class="ft-rotate-cw"></i></a></li>
                            <li><a data-action="expand" title="<?php echo app('translator')->get('admin.sections.card.expand'); ?>"><i class="ft-maximize"></i></a></li>
                            <li><a data-action="close" title="<?php echo app('translator')->get('admin.sections.card.close'); ?>"><i class="ft-x"></i></a></li>
                            <li>
                                <a href="<?php echo e(route('admin.sections.create')); ?>" class="btn btn-sm btn-primary">
                                    <i class="ft-plus"></i> <?php echo app('translator')->get('admin.sections.create_button'); ?>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="card-content collapse show">
                    <div class="card-body card-dashboard">
                        <table class="table table-striped table-bordered zero-configuration">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('admin.sections.table.name_ar'); ?></th>
                                    <th><?php echo app('translator')->get('admin.sections.table.name_en'); ?></th>
                                    <th><?php echo app('translator')->get('admin.sections.table.image'); ?></th>
                                    <th style="width: 120px"><?php echo app('translator')->get('admin.sections.table.actions'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($section->getTranslation('name', 'ar') ?? '-'); ?></td>
                                    <td><?php echo e($section->getTranslation('name', 'en') ?? '-'); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('storage/'. $section->image)); ?>" alt="<?php echo e($section->name); ?>" width="100">
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <a href="<?php echo e(route('admin.sections.show', $section->id)); ?>" 
                                               class="btn btn-sm btn-outline-primary" 
                                               title="<?php echo app('translator')->get('admin.sections.actions.view'); ?>">
                                                <i class="ft-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.sections.edit', $section->id)); ?>" 
                                               class="btn btn-sm btn-outline-warning" 
                                               title="<?php echo app('translator')->get('admin.sections.actions.edit'); ?>">
                                                <i class="ft-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('admin.sections.destroy', $section->id)); ?>" 
                                                  method="POST" 
                                                  class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" 
                                                        class="btn btn-sm btn-outline-danger" 
                                                        title="<?php echo app('translator')->get('admin.sections.actions.delete'); ?>"
                                                        onclick="return confirm('<?php echo app('translator')->get('admin.sections.actions.delete_confirm'); ?>')">
                                                    <i class="ft-trash-2"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="text-center"><?php echo app('translator')->get('admin.sections.table.no_data'); ?></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\electronic-blog\resources\views/admin/sections/index.blade.php ENDPATH**/ ?>