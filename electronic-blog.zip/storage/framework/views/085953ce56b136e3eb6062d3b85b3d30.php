
<?php $__env->startSection('content'); ?>

<div class="col-xl-8 col-lg-10 mx-auto">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title"><?php echo app('translator')->get('admin.sections.details.title', ['id' => $section->id]); ?></h4>
        </div>
        <div class="card-content">
            <div class="card-body">
                <div class="row mt-2">
                    <?php $__currentLoopData = config('app.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <h5><?php echo app('translator')->get('admin.sections.details.name'); ?> (<?php echo e(strtoupper($locale)); ?>)</h5>
                        <p><?php echo e($section->getTranslation('name', $locale) ?? '-'); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                <div class="row mt-2">
                    <div class="col-md-6">
                        <h5><?php echo app('translator')->get('admin.sections.details.image'); ?></h5>
                        <img src="<?php echo e(asset('storage/'. $section->image)); ?>" alt="<?php echo e($section->name); ?>" class="img-thumbnail" width="200">
                    </div>
                </div>
                
                <div class="form-actions right mt-3">
                    <a href="<?php echo e(route('admin.sections.index')); ?>" class="btn btn-primary">
                        <i class="ft-arrow-left"></i> <?php echo app('translator')->get('admin.sections.details.back_button'); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\electronic-blog\resources\views/admin/sections/show.blade.php ENDPATH**/ ?>