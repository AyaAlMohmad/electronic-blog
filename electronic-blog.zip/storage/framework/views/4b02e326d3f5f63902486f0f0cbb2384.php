

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title"><?php echo app('translator')->get('admin.writers.show.title'); ?></h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 text-center">
                    <?php if($writer->image): ?>
                        <img src="<?php echo e($writer->image); ?>" class="img-fluid rounded-circle mb-3" style="max-width: 200px;">
                    <?php endif; ?>
                    <h3><?php echo e($writer->name); ?></h3>
                    <p class="text-muted"><?php echo app('translator')->get('admin.writers.show.member_since', ['date' => $writer->user->created_at->format('M d, Y')]); ?></p>
                </div>

                <div class="col-md-8">
                    <div class="mb-4">
                        <h5><?php echo app('translator')->get('admin.writers.show.biography'); ?></h5>
                        <p><?php echo e($writer->bio); ?></p>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h6 class="card-title"><?php echo app('translator')->get('admin.writers.show.user_info'); ?></h6>
                                    <p><strong><?php echo app('translator')->get('admin.writers.approve.email'); ?>:</strong><a href="mailto:<?php echo e($writer->user->email); ?>"> <?php echo e($writer->user->email); ?></a></p>
                                    <p><strong><?php echo app('translator')->get('admin.writers.show.status'); ?>:</strong> 
                                        <span class="badge badge-success"><?php echo app('translator')->get('admin.writers.show.approved_writer'); ?></span>
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h6 class="card-title"><?php echo app('translator')->get('admin.writers.show.writer_details'); ?></h6>
                                    <p><strong><?php echo app('translator')->get('admin.writers.approve.subsection'); ?>:</strong> <?php echo e($writer->subsection->name); ?></p>
                                    <p><strong><?php echo app('translator')->get('admin.writers.show.articles_written'); ?>:</strong> <?php echo e($postCount); ?></p>
                                    <p><strong><?php echo app('translator')->get('admin.writers.show.approved_on'); ?>:</strong> <?php echo e($writer->created_at->format('M d, Y')); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="text-right mt-3">
                        <a href="<?php echo e(route('admin.writers.approved')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> <?php echo app('translator')->get('admin.writers.show.back_button'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\electronic-blog\resources\views/admin/writers/show.blade.php ENDPATH**/ ?>