<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900">
            <?php echo e(__('Profile Information')); ?>

        </h2>

        <p class="mt-1 text-sm text-gray-600">
            <?php echo e(__("Update your account's profile information and email address.")); ?>

        </p>
    </header>

    <form id="send-verification" method="post" action="<?php echo e(route('verification.send')); ?>">
        <?php echo csrf_field(); ?>
    </form>

    <form method="post" action="<?php echo e(route('profile.update')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>

        <div style="margin-bottom: 20px;">
            <label for="name" style="display: block; font-weight: 500; color: #374151; margin-bottom: 6px;">
                <?php echo e(__('Name')); ?>

            </label>
            <input 
                id="name" 
                name="name" 
                type="text" 
                value="<?php echo e(old('name', $user->name)); ?>" 
                required 
                autofocus 
                autocomplete="name"
                style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;"
            >
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: red; font-size: 12px; margin-top: 4px;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div style="margin-bottom: 20px;">
            <label for="email" style="display: block; font-weight: 500; color: #374151; margin-bottom: 6px;">
                <?php echo e(__('Email')); ?>

            </label>
            <input 
                id="email" 
                name="email" 
                type="email" 
                value="<?php echo e(old('email', $user->email)); ?>" 
                required 
                autocomplete="username"
                style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;"
            >
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: red; font-size: 12px; margin-top: 4px;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail()): ?>
                <div style="margin-top: 10px;">
                    <p style="font-size: 14px; color: #374151;">
                        <?php echo e(__('Your email address is unverified.')); ?>


                        <button 
                            form="send-verification" 
                            type="submit"
                            style="font-size: 14px; text-decoration: underline; color: #4b5563; cursor: pointer; border: none; background: none; padding: 0;"
                        >
                            <?php echo e(__('Click here to re-send the verification email.')); ?>

                        </button>
                    </p>

                    <?php if(session('status') === 'verification-link-sent'): ?>
                        <p style="margin-top: 8px; font-weight: 500; font-size: 14px; color: #059669;">
                            <?php echo e(__('A new verification link has been sent to your email address.')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <div style="display: flex; align-items: center; gap: 16px; margin-top: 24px;">
            <button 
                type="submit"
                style="background-color: #1f2937; color: white; padding: 8px 16px; font-size: 14px; border-radius: 6px; border: none; cursor: pointer;"
            >
                <?php echo e(__('Save')); ?>

            </button>

            <?php if(session('status') === 'profile-updated'): ?>
                <p 
                    x-data="{ show: true }"
                    x-show="show"
                    x-transition
                    x-init="setTimeout(() => show = false, 2000)"
                    style="font-size: 14px; color: #6b7280;"
                >
                    <?php echo e(__('Saved.')); ?>

                </p>
            <?php endif; ?>
        </div>
    </form>
</section>
<?php /**PATH C:\laragon\www\electronic-blog\resources\views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>