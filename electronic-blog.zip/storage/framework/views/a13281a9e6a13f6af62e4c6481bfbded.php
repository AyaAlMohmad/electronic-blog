
<?php $__env->startSection('content'); ?>

<section id="configuration">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo app('translator')->get('admin.about_us.index.title'); ?></h4>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse" title="<?php echo app('translator')->get('admin.about_us.index.card.collapse'); ?>"><i class="ft-minus"></i></a></li>
                            <li><a data-action="reload" title="<?php echo app('translator')->get('admin.about_us.index.card.reload'); ?>"><i class="ft-rotate-cw"></i></a></li>
                            <li><a data-action="expand" title="<?php echo app('translator')->get('admin.about_us.index.card.expand'); ?>"><i class="ft-maximize"></i></a></li>
                            <li><a data-action="close" title="<?php echo app('translator')->get('admin.about_us.index.card.close'); ?>"><i class="ft-x"></i></a></li>
                            <li>
                                <a href="<?php echo e(route('admin.about_us.create')); ?>" class="btn btn-sm btn-primary">
                                    <i class="ft-plus"></i> <?php echo app('translator')->get('admin.about_us.index.create_button'); ?>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="card-content collapse show">
                    <div class="card-body card-dashboard">
                        <table class="table table-striped table-bordered zero-configuration">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('admin.about_us.index.table.title_ar'); ?></th>
                                    <th><?php echo app('translator')->get('admin.about_us.index.table.title_en'); ?></th>
                                    <th><?php echo app('translator')->get('admin.about_us.index.table.short_description_ar'); ?></th>
                                    <th><?php echo app('translator')->get('admin.about_us.index.table.short_description_en'); ?></th>
                                    <th><?php echo app('translator')->get('admin.about_us.index.table.image'); ?></th>
                                    <th style="width: 120px"><?php echo app('translator')->get('admin.about_us.index.table.actions'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $about_us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($about->getTranslation('title', 'ar') ?? '-'); ?></td>
                                    <td><?php echo e($about->getTranslation('title', 'en') ?? '-'); ?></td>
                                    <td><?php echo e($about->getTranslation('short_description', 'ar') ?? '-'); ?></td>
                                    <td><?php echo e($about->getTranslation('short_description', 'en') ?? '-'); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('storage/'.$about->image)); ?>" 
                                             alt="about us image" 
                                             style="width: 100px; height: 100px;">
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <a href="<?php echo e(route('admin.about_us.show', $about->id)); ?>" 
                                               class="btn btn-sm btn-outline-primary" 
                                               title="<?php echo app('translator')->get('admin.about_us.index.actions.view'); ?>">
                                                <i class="ft-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.about_us.edit', $about->id)); ?>" 
                                               class="btn btn-sm btn-outline-warning" 
                                               title="<?php echo app('translator')->get('admin.about_us.index.actions.edit'); ?>">
                                                <i class="ft-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('admin.about_us.destroy', $about->id)); ?>" 
                                                  method="POST" 
                                                  class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" 
                                                        class="btn btn-sm btn-outline-danger" 
                                                        title="<?php echo app('translator')->get('admin.about_us.index.actions.delete'); ?>"
                                                        onclick="return confirm('<?php echo app('translator')->get('admin.about_us.index.actions.delete_confirm'); ?>')">
                                                    <i class="ft-trash-2"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center"><?php echo app('translator')->get('admin.about_us.index.table.no_data'); ?></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\electronic-blog\resources\views/admin/about_us/index.blade.php ENDPATH**/ ?>