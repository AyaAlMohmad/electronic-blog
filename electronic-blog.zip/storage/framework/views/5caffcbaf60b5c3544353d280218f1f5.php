

<?php $__env->startSection('content'); ?>
    <section id="configuration">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo app('translator')->get('admin.posts.pending.title'); ?></h4>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="collapse" title="<?php echo app('translator')->get('admin.posts.pending.card.collapse'); ?>"><i class="ft-minus"></i></a></li>
                                <li><a data-action="reload" title="<?php echo app('translator')->get('admin.posts.pending.card.reload'); ?>"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand" title="<?php echo app('translator')->get('admin.posts.pending.card.expand'); ?>"><i class="ft-maximize"></i></a></li>
                                <li><a data-action="close" title="<?php echo app('translator')->get('admin.posts.pending.card.close'); ?>"><i class="ft-x"></i></a></li>
                                <li>
                                    <a href="<?php echo e(route('admin.posts.approved')); ?>" class="btn btn-sm btn-primary">
                                        <i class="ft-check"></i> <?php echo app('translator')->get('admin.posts.pending.approved_button'); ?>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="card-content collapse show">
                        <div class="card-body card-dashboard">
                            <table class="table table-striped table-bordered zero-configuration">
                                <thead>
                                    <tr>
                                        <th><?php echo app('translator')->get('admin.posts.pending.table.id'); ?></th>
                                        <th><?php echo app('translator')->get('admin.posts.pending.table.title'); ?></th>
                                        <th><?php echo app('translator')->get('admin.posts.pending.table.writer'); ?></th>
                                        <th><?php echo app('translator')->get('admin.posts.pending.table.date'); ?></th>
                                        <th><?php echo app('translator')->get('admin.posts.pending.table.image'); ?></th>
                                        <th><?php echo app('translator')->get('admin.posts.pending.table.action_type'); ?></th>
                                        <th style="width: 150px"><?php echo app('translator')->get('admin.posts.pending.table.actions'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($post->id); ?></td>
                                            <td><?php echo e($post->title); ?></td>
                                            <td><?php echo e($post->writer?->name ?? 'N/A'); ?></td>
                                            <td><?php echo e($post->date ?? 'N/A'); ?></td>
                                            <td>
                                                <?php if($post->image): ?>
                                                    <img src="<?php echo e($post->image); ?>" width="50" class="rounded">
                                                <?php else: ?>
                                                    <span class="badge badge-light"><?php echo app('translator')->get('admin.posts.details.no_image'); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($post->action_type === 'create'): ?>
                                                    <span class="badge badge-success"><?php echo app('translator')->get('admin.posts.pending.table.new'); ?></span>
                                                <?php else: ?>
                                                    <span class="badge badge-warning"><?php echo app('translator')->get('admin.posts.pending.table.edited'); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                               <a href="<?php echo e(route('admin.posts.show', $post->id)); ?>"
                                                    class="btn btn-sm btn-outline-primary" title="<?php echo app('translator')->get('admin.posts.pending.actions.view'); ?>">
                                                    <i class="ft-eye"></i>
                                                </a>
                                            
                                               <form action="<?php echo e(route('admin.posts.approve', $post->id)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-success" title="<?php echo app('translator')->get('admin.posts.pending.actions.approve'); ?>">
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                </form>
                                            
                                               <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="<?php echo app('translator')->get('admin.posts.pending.actions.delete'); ?>"
                                                        onclick="return confirm('<?php echo app('translator')->get('admin.posts.pending.actions.confirm_delete'); ?>')">
                                                        <i class="ft-trash-2"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="7" class="text-center"><?php echo app('translator')->get('admin.posts.pending.table.no_data'); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\electronic-blog\resources\views/admin/posts/pending.blade.php ENDPATH**/ ?>