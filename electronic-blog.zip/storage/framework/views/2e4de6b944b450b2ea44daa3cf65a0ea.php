

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title"><?php echo app('translator')->get('admin.writers.approved.title'); ?></h4>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->get('admin.writers.approved.table.id'); ?></th>
                            <th><?php echo app('translator')->get('admin.writers.approved.table.name'); ?></th>
                            <th><?php echo app('translator')->get('admin.writers.approved.table.email'); ?></th>
                            <th><?php echo app('translator')->get('admin.writers.approved.table.profile'); ?></th>
                            <th><?php echo app('translator')->get('admin.writers.approved.table.actions'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $writers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php if($user->writer && $user->writer->image): ?>
                                    <img src="<?php echo e($user->writer->image); ?>" width="50" class="rounded-circle">
                                <?php else: ?>
                                    <span class="badge badge-light"><?php echo app('translator')->get('admin.writers.approved.table.no_image'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.writers.show', $user->writer->id)); ?>" 
                                   title="<?php echo app('translator')->get('admin.writers.approved.actions.view'); ?>"  
                                   class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-eye"></i> 
                                </a>
                                <form action="<?php echo e(route('admin.writers.revoke', $user->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-warning" 
                                            title="<?php echo app('translator')->get('admin.writers.approved.actions.revoke'); ?>" 
                                            onclick="return confirm('<?php echo app('translator')->get('admin.writers.approved.actions.revoke_confirm'); ?>')">
                                        <i class="fas fa-user-minus"></i> 
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center"><?php echo app('translator')->get('admin.writers.approved.table.no_data'); ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\electronic-blog\resources\views/admin/writers/approved.blade.php ENDPATH**/ ?>