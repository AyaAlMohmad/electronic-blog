

<?php $__env->startSection('content'); ?>
<div class="container" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title"><?php echo e(__('Approve Writer')); ?>: <?php echo e($user->name); ?></h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.writers.approve', $user->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo e(__('Current User Info')); ?></label>
                            <div class="form-control-plaintext">
                                <p><strong><?php echo e(__('Name')); ?>:</strong> <?php echo e($user->name); ?></p>
                                <p><strong><?php echo e(__('Email')); ?>:</strong> <?php echo e($user->email); ?></p>
                                <?php if($user->image_path): ?>
                                    <img src="<?php echo e($user->image_path); ?>" width="100" class="img-thumbnail mt-2">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        
                        <div class="form-group">
                            <label for="bio_ar"><?php echo e(__('Biography (Arabic)')); ?>*</label>
                            <textarea name="bio[ar]" id="bio_ar" class="form-control" rows="3" required></textarea>
                        </div>

                        
                        <div class="form-group">
                            <label for="bio_en"><?php echo e(__('Biography (English)')); ?>*</label>
                            <textarea name="bio[en]" id="bio_en" class="form-control" rows="3" required></textarea>
                        </div>

                        <div class="form-group">
                            <label for="subsection_id"><?php echo e(__('Subsection')); ?>*</label>
                            <select name="subsection_id" id="subsection_id" class="form-control" required>
                                <option value=""><?php echo e(__('Select Subsection')); ?></option>
                                <?php $__currentLoopData = $subsections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subsection->id); ?>">
                                        <?php echo e($subsection->getTranslation('name', app()->getLocale())); ?> -> <?php echo e($subsection->section->getTranslation('name', app()->getLocale())); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="image"><?php echo e(__('Profile Image')); ?></label>
                            <input type="file" name="image" id="image" class="form-control-file">
                            <small class="form-text text-muted"><?php echo e(__('Leave empty to use current profile image')); ?></small>
                        </div>
                    </div>
                </div>

                <div class="form-group text-right mt-4">
                    <a href="<?php echo e(route('admin.writers.pending')); ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> <?php echo e(__('Back')); ?>

                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check"></i> <?php echo e(__('Approve Writer')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\electronic-blog\resources\views/admin/writers/approve.blade.php ENDPATH**/ ?>