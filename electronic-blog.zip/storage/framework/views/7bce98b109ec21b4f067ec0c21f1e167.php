

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title"><?php echo app('translator')->get('admin.posts.approved.title'); ?></h4>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="mb-3">
                <a href="<?php echo e(route('admin.posts.pending')); ?>" class="btn btn-sm btn-primary">
                    <i class="ft-check"></i> <?php echo app('translator')->get('admin.posts.approved.pending_button'); ?>
                </a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->get('admin.posts.approved.table.id'); ?></th>
                            <th><?php echo app('translator')->get('admin.posts.approved.table.title'); ?></th>
                            <th><?php echo app('translator')->get('admin.posts.approved.table.writer'); ?></th>
                            <th><?php echo app('translator')->get('admin.posts.approved.table.date'); ?></th>
                            <th><?php echo app('translator')->get('admin.posts.approved.table.image'); ?></th>
                            <th><?php echo app('translator')->get('admin.posts.approved.table.actions'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($post->id); ?></td>
                            <td><?php echo e($post->title); ?></td>
                            <td><?php echo e($post->writer?->name ?? 'N/A'); ?></td>
                            <td><?php echo e($post->date ?? 'N/A'); ?></td>
                            <td>
                                <?php if($post->image): ?>
                                    <img src="<?php echo e($post->image); ?>" width="60" class="rounded">
                                <?php else: ?>
                                    <span class="badge badge-light"><?php echo app('translator')->get('admin.posts.details.no_image'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.posts.show', $post->id)); ?>" class="btn btn-sm btn-outline-primary" title="<?php echo app('translator')->get('admin.posts.approved.actions.view'); ?>">
                                    <i class="fas fa-eye"></i> 
                                </a>
                            
                                <form action="<?php echo e(route('admin.posts.approve', $post->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-success" title="<?php echo app('translator')->get('admin.posts.approved.actions.approve'); ?>" onclick="return confirm('<?php echo app('translator')->get('admin.posts.approved.actions.confirm_approve'); ?>')">
                                        <i class="fas fa-check-circle"></i> 
                                    </button>
                                </form>
                            
                                <form action="<?php echo e(route('admin.posts.reject', $post->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-warning" title="<?php echo app('translator')->get('admin.posts.approved.actions.reject'); ?>" onclick="return confirm('<?php echo app('translator')->get('admin.posts.approved.actions.confirm_reject'); ?>')">
                                        <i class="fas fa-times-circle"></i> 
                                    </button>
                                </form>
                            
                                <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="<?php echo app('translator')->get('admin.posts.approved.actions.delete'); ?>" onclick="return confirm('<?php echo app('translator')->get('admin.posts.approved.actions.confirm_delete'); ?>')">
                                        <i class="fas fa-trash-alt"></i> 
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center"><?php echo app('translator')->get('admin.posts.approved.table.no_data'); ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\electronic-blog\resources\views/admin/posts/approved.blade.php ENDPATH**/ ?>