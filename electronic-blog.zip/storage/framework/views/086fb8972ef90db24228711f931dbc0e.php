<div class="main-menu-content">
    <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
        <li class="nav-item <?php echo e(Route::is('admin.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.index')); ?>">
                <i class="ft-home"></i>
                <span><?php echo e(__('sidebar.dashboard')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php echo e(Route::is('admin.sections.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.sections.index')); ?>">
                <i class="ft-bar-chart-2"></i>
                <span><?php echo e(__('sidebar.sections')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php echo e(Route::is('admin.subsections.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.subsections.index')); ?>">
                <i class="ft-list"></i>
                <span><?php echo e(__('sidebar.sub_sections')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php echo e(Route::is('admin.posts.pending') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.posts.pending')); ?>">
                <i class="ft-file-text"></i>
                <span><?php echo e(__('sidebar.posts')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php echo e(Route::is('admin.about_us.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.about_us.index')); ?>">
                <i class="ft-info"></i>
                <span><?php echo e(__('sidebar.about_us')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php echo e(Route::is('admin.contact_us.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.contact_us.index')); ?>">
                <i class="ft-phone"></i>
                <span><?php echo e(__('sidebar.contact_us')); ?></span>
            </a>
        </li>
        <li class="nav-item has-submenu <?php echo e(Route::is('admin.users.*') ? 'active' : ''); ?>">
            <a href="#">
                <i class="ft-users"></i>
                <span><?php echo e(__('sidebar.users')); ?></span>
            </a>
            <ul class="submenu">
                <li class="<?php echo e(Route::is('admin.users.index') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.users.index')); ?>">
                        <i class="ft-user"></i>
                        <span><?php echo e(__('sidebar.all_users')); ?></span>
                    </a>
                </li>
                <li class="<?php echo e(Route::is('admin.writers.pending') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.writers.pending')); ?>">
                        <i class="fa fa-pencil"></i>
                        <span><?php echo e(__('sidebar.writers')); ?></span>
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</div>
<?php /**PATH C:\laragon\www\electronic-blog\resources\views/layouts/includs/sidbar.blade.php ENDPATH**/ ?>