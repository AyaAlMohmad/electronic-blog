

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Post Details</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 text-center">
                    <?php if($post->image): ?>
                        <img src="<?php echo e($post->image); ?>" class="img-fluid rounded mb-3" style="max-width: 300px;">
                    <?php else: ?>
                        <span class="badge badge-light">No Image</span>
                    <?php endif; ?>

                    <?php if($post->video): ?>
                        <div class="mt-3">
                            <video controls width="100%">
                                <source src="<?php echo e($post->video); ?>" type="video/mp4">
                                Your browser does not support the video tag.
                            </video>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-md-8">
                    <h3><?php echo e($post->title); ?></h3>
                    <p class="text-muted">Date: <?php echo e($post->date); ?></p>

                    <div class="mb-3">
                        <h5>Short Description</h5>
                        <p><?php echo e($post->short_description); ?></p>
                    </div>

                    <div class="mb-3">
                        <h5>Description</h5>
                        <p><?php echo nl2br(e($post->description)); ?></p>
                    </div>

                    <div class="mb-4">
                        <h5>Writer</h5>
                        <p><strong><?php echo e($post->writer->name ?? 'Unknown'); ?></strong></p>
                    </div>

                    <div class="text-right">
                        <a href="<?php echo e(route('admin.posts.approved')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back to List
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\electronic-blog\resources\views/admin/posts/show.blade.php ENDPATH**/ ?>