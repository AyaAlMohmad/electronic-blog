
<?php $__env->startSection('content'); ?>
<div class="col-xl-8 col-lg-10 mx-auto">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title"><?php echo app('translator')->get('admin.sections.edit.title'); ?></h4>
        </div>
        <div class="card-content">
            <div class="card-body">
                <form action="<?php echo e(route('admin.sections.update',$section->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="nav-tabs-top">
                        <ul class="nav nav-tabs" role="tablist">
                            <?php $__currentLoopData = config('app.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" 
                                   data-toggle="tab" 
                                   href="#tab-<?php echo e($locale); ?>" 
                                   aria-expanded="true">
                                   <?php echo e(strtoupper($locale)); ?>

                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        
                        <div class="tab-content px-1 pt-1">
                            <?php $__currentLoopData = config('app.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane <?php echo e($loop->first ? 'active' : ''); ?>" 
                                 id="tab-<?php echo e($locale); ?>" 
                                 aria-expanded="true" 
                                 role="tabpanel">
                                <div class="form-group">
                                    <label for="name_<?php echo e($locale); ?>">
                                        <?php echo app('translator')->get('admin.sections.form.name'); ?> (<?php echo e(strtoupper($locale)); ?>)
                                    </label>
                                    <input type="text" 
                                           class="form-control" 
                                           id="name_<?php echo e($locale); ?>" 
                                           name="name[<?php echo e($locale); ?>]" 
                                           value="<?php echo e($section->getTranslation('name', $locale)); ?>"
                                           placeholder="<?php echo app('translator')->get('admin.sections.form.name_placeholder', ['locale' => $locale]); ?>">
                                    <?php $__errorArgs = ['name.'.$locale];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="image"><?php echo app('translator')->get('admin.sections.form.image'); ?></label>
                        <img src="<?php echo e(asset('storage/'. $section->image)); ?>" alt="<?php echo e($section->name); ?>" class="img-thumbnail mb-2" width="100">
                        <input type="file" class="form-control" id="image" name="image">
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-actions right mt-3">
                        <a href="<?php echo e(route('admin.sections.index')); ?>" class="btn btn-warning mr-1">
                            <i class="ft-x"></i> <?php echo app('translator')->get('admin.sections.edit.cancel'); ?>
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fa fa-check-square-o"></i> <?php echo app('translator')->get('admin.sections.edit.submit'); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\electronic-blog\resources\views/admin/sections/edit.blade.php ENDPATH**/ ?>