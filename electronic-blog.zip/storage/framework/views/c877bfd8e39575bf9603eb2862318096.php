
<?php $__env->startSection('content'); ?>

<div class="col-xl-8 col-lg-10 mx-auto">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title"><?php echo e(__('user Details')); ?>  <?php echo e($user->id); ?></h4>
        </div>
        <div class="card-content">
            <div class="card-body">

                
                <div class="row mt-2">
           
                    <div class="col-md-6">
                        <h5><?php echo e(__('Name')); ?> </h5>
                        <p><?php echo e($user->name); ?></p>
                    </div>
                    <div class="col-md-6">
                        <h5><?php echo e(__('Email')); ?> </h5>
                        <p><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></p>
                    </div>
        
                </div>
                
                <div class="row mt-2">
                    <div class="col-md-6">
                        <h5><?php echo e(__('Image')); ?></h5>
                        <img src="<?php echo e($user->image_path); ?>" alt="<?php echo e($user->name); ?>" width="100">
                    </div>
                </div>
                <div class="form-actions right mt-3">
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-primary">
                        <i class="ft-arrow-left"></i> <?php echo e(__('Back')); ?>

                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\electronic-blog\resources\views/admin/users/show.blade.php ENDPATH**/ ?>